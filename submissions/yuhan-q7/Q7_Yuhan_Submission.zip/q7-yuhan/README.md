# Yuhan Hu — Q7 / sketch YH-02

**Question:** How much more do nonstop flights cost than connecting flights around the holidays?

This submission provides the validated fare aggregates and reproducible data-processing code for the Tableau comparison and the site's nonstop-versus-connecting view.

## Tableau visualization

Open `visualizations/Q7_Nonstop_vs_Connecting.twbx` in Tableau. The small chart dataset is included in the package.

The worksheet, **Price the nonstop before you assume the connection is cheaper.**, was recovered from Tableau's October 20, 2026, 15:25 EDT automatic save. The shareable copy preserves that worksheet and its July 4 filter and removes an unrelated second worksheet and its large unused data source. The user's original recovery file is unchanged. Edits made after that automatic save are not included. The workbook's native rendering could not be checked in Tableau during packaging.

## Data for drawing the chart

- `data/Q7_Tableau_chart.csv`: eight rows, one for each travel period and flight type. Fields are `holiday`, `flightType`, `medianFare`, and `quoteCount`. The fare is an already-computed median in USD, including taxes and fees.
- `data/Q7_route_comparison.csv`: one row per period, directional airport route, and flight type. Select `hasBothFlightTypes=True` for a route with both alternatives.
- `data/Q7_website_data.json`: the same overall and route aggregates, plus dollar and percentage differences, for use in the existing D3 implementation.
- `data/validation.json`: reconciliation and independent verification of the export.

In Tableau, use `flightType` on Rows, `AVG(medianFare)` on Columns, and `holiday` as a single-value filter. Each bar must contain the one summary record for its selected period and type. For all periods, add `holiday` before `flightType` on Rows. For a route-specific chart, use the route table and filter to one period and one route. Do not sum or average route medians to reconstruct an overall median.

## Overall results

| Travel period | Nonstop median (USD) | Connecting median (USD) | Nonstop minus connecting (USD) |
| --- | ---: | ---: | ---: |
| Memorial Day | 258.60 | 408.61 | -150.01 |
| July 4 | 255.60 | 417.69 | -162.09 |
| Labor Day | 208.61 | 317.60 | -108.99 |
| Non-holiday | 238.60 | 392.70 | -154.10 |

A negative difference means nonstop was cheaper in the pooled sample. The question does not require the difference to be positive.

## Definitions and limitations

Source: [Dillon Wong's Expedia Flight Prices dataset](https://www.kaggle.com/datasets/dilwong/flightprices).

Flight departure windows match the team's website, with inclusive endpoints in 2022:

- Memorial Day: May 26–31.
- July 4: June 30–July 5.
- Labor Day: September 1–6.
- Non-holiday: June 9–14 and August 11–16, pooled.

The six-column source contained 82,138,753 observed fare records. The selected windows retained 13,066,299 records, with no invalid selected records. No random sampling or flight-level deduplication was performed. `quoteCount` counts observations, including repeat checks across search dates, rather than unique flights or tickets sold.

The overall bars pool different routes, dates and booking lead times. They do not isolate the effect of a stop. Same-route comparisons can reverse the overall result: in the July 4 window, ATL–BOS medians are $398.60 nonstop and $342.20 connecting. Use route-specific data if the final site claims to compare the same trip. Booking lead times and other ticket characteristics still vary.

The site's layover marker and flight paths are schematic illustrations, not measured stop locations, durations or separately priced fees.

## Reproduce the data

`code/prepare_q7.py` uses Python's standard library. Obtain the original dataset and a six-column CSV in this order:

`searchDate,flightDate,startingAirport,destinationAirport,isNonStop,totalFare`

Run:

```sh
python3 code/prepare_q7.py --input flightprices_six_columns.csv --output regenerated
```

The script retains every valid quote in the specified windows, adds period/type/route/lead-time fields, and computes exact medians from fare-frequency counts. The large record-level file can be regenerated; the small summary tables here are sufficient for drawing the submitted comparison.

The existing website's D3 code renders the interactive scene, including the schematic layover and animation. The Python file above processes data; it is not Tableau rendering code. The packaged Tableau workbook above provides the editable chart reference. No native Tableau PNG export is included.
